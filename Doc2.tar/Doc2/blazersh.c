#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include <sys/wait.h>

//These are some tokens constants which will be used to split input 
#define LSH_TOK_BUFSIZE 64
#define LSH_TOK_DELIM " \t\r\n\a"

// This split user input to a more meaningful token such that It can be processes by blazersh shel
char **blazersh_split_line(char *line)
{
  int bufsize = LSH_TOK_BUFSIZE, position = 0;
  char **tokens = malloc(bufsize * sizeof(char*));
  char *token;

  if (!tokens) {
    fprintf(stderr, "lsh: allocation error\n");
    exit(EXIT_FAILURE);
  }

  token = strtok(line, LSH_TOK_DELIM);
  while (token != NULL) {
    tokens[position] = token;
    position++;

    if (position >= bufsize) {
      bufsize += LSH_TOK_BUFSIZE;
      tokens = realloc(tokens, bufsize * sizeof(char*));
      if (!tokens) {
        fprintf(stderr, "lsh: allocation error\n");
        exit(EXIT_FAILURE);
      }
    }

    token = strtok(NULL, LSH_TOK_DELIM);
  }
  tokens[position] = NULL;
  return tokens;
}

// Read input from user : These will be processed by blazersh
char *blazersh_read_line(void)
{
  char *line = NULL;
  ssize_t bufsize = 0;  
  getline(&line, &bufsize, stdin);
  return line;
}

//Quit helper function
void safe_quit(){
	exit(0);
}

//help function
void blazer_help(){

  printf("blazer shell....\n");
  printf("Type program names and arguments, and hit enter.\n");
  printf("The following are built in:\n");
  printf("environ\nset\nlist\ncd\nhelp\nquit\n");

}

//implementation of change directory helper
int blazer_cd(char **args){

  if (args[1] == NULL) {
    fprintf(stderr, "lsh: expected argument to \"cd\"\n");
  } else {
    if (chdir(args[1]) != 0) {
      perror("lsh");
    }
  }
  return 1;

}

//set environment variables
void blazer_set(char **args)
{
	setenv(args[1], args[2],1);
}

// This will spawn a new process using fork and then will process the input.
// Parent will keep waiting for child process and will display result on foreground
int blazersh_execute(char **args)
{
  pid_t pid, wpid;
  int status;
  // Helper functions initialize
  if(strcmp(args[0], "quit") == 0){
    //Execute help function
    safe_quit();
    return 1;
  }else if (strcmp(args[0], "help")==0){
    blazer_help();
    return 1;
  }else if (strcmp(args[0], "cd")==0){
    blazer_cd(args);
    return 1;
  }else if (strcmp(args[0], "list")==0){
    args[0] = "ls";
  }else if (strcmp(args[0], "set")==0){
    blazer_set(args);
    return 1;
  }else if (strcmp(args[0], "environ")==0){
    args[0] = "env";
  }

  // Done with helper function: Its time to fork
  pid = fork();
  if (pid == 0) {
    // Child process
    if (execvp(args[0], args) == -1) {
      perror("lsh");
    }
    exit(EXIT_FAILURE);
  } else if (pid < 0) {
    // Error forking
    perror("lsh");
  } else {
    // Parent process
    do {
      wpid = waitpid(pid, &status, WUNTRACED);
    } while (!WIFEXITED(status) && !WIFSIGNALED(status));
  }

  return 1;
}

//This is blazer shell main loop which keeps on running forever
void blazersh_loop()
{

  char *line;
  char **args;
  int status;

  // Keep running loop to accept new commands/user inputs
  do {
    printf("blazersh>");
    line = blazersh_read_line();
    args = blazersh_split_line(line);
    status = blazersh_execute(args);

    free(line);
    free(args);
  } while (status);

}

// Main function from where execution will start.
int main(int argc, char **argv)
{

  // Run blazer shell main loop.
  blazersh_loop();

  return 0;
}
