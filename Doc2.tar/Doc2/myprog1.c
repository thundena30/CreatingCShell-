#include<stdio.h>

//This is a test program for blazer shell
int main(int argc, char **argv)
{
	printf("Hello World!\n");
}
