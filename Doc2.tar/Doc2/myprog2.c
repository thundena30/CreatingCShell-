#include<stdio.h>
#include<stdio.h>
#include<string.h>

int main(int argc, char **argv)
{
	int num =0;
	if(argc < 2){
		printf("Enter the number of elements:");
		scanf("%d",&num);
	}
	else {
		// Update number of elements here
		num = atoi(argv[1]);
	}
	printf("\n");
	int count = 10;
	for (int i =0;i<num;i++)
		printf("%d ",count + i);

	return 0;
}
