#include<stdio.h>
#include<stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char **argv)
{
	if(argc != 7)
	{
		printf("Wrong number of arguments to myprogram\n");
	}

	int fd0 = open(argv[4], O_RDONLY);
        dup2(fd0, STDIN_FILENO);
        close(fd0);

	int fd1 = creat(argv[6] , 0644) ;
        dup2(fd1, STDOUT_FILENO);
        close(fd1);
	

	// let's perform some operations on i/o re-direction.
	char buf[1];
	while(read(0, buf, sizeof(buf))>0) {
	 write(1,buf, sizeof(buf));
	}
}
